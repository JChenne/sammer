#ifndef __TIME4_H
#define __TIME4_H

#include "stm32f10x.h"
 
void TIM4_NVIC_Configuration(void);
void TIM4_Configuration(void);
void TIM4_Config(void);

#endif	/* TIME_TEST_H */
