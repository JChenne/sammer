#ifndef __TIME2_H
#define __TIME2_H

#include "stm32f10x.h"
 
void TIM2_NVIC_Configuration(void);
void TIM2_Configuration(void);
void TIM2_Config(void);

#endif	/* TIME_TEST_H */
