#ifndef __SONIC_H__
#define __SONIC_H__

#include "stm32f10x.h"

void Sonic_Trig(void);
void Sonic_Init(void);
void TIM6_Init(void);
void TIM4_Init(void);

#endif	/* __SONIC_H__ */
